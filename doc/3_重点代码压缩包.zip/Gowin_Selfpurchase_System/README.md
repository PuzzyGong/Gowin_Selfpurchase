# Gowin_Selfpurchase_System
a project for a FPGA competition on Oct.&amp;Nov. in 2022
